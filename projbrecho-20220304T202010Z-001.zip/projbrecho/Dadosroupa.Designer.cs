﻿using System;

namespace Projetobrecho
{
    partial class Dadosroupa
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtcpfdoador = new System.Windows.Forms.TextBox();
            this.rbtcpfdoador = new System.Windows.Forms.RadioButton();
            this.rbtnomepet = new System.Windows.Forms.RadioButton();
            this.btnpesquisarroupa = new System.Windows.Forms.Button();
            this.txtmodelodados = new System.Windows.Forms.TextBox();
            this.txtcpfdoadordados = new System.Windows.Forms.TextBox();
            this.txtcordados = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.btnalterarroupa = new System.Windows.Forms.Button();
            this.btnexcluirroupa = new System.Windows.Forms.Button();
            this.cbxmodelo = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txttamanhodados = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // txtcpfdoador
            // 
            this.txtcpfdoador.Location = new System.Drawing.Point(196, 48);
            this.txtcpfdoador.Margin = new System.Windows.Forms.Padding(4);
            this.txtcpfdoador.Name = "txtcpfdoador";
            this.txtcpfdoador.Size = new System.Drawing.Size(141, 26);
            this.txtcpfdoador.TabIndex = 0;
            // 
            // rbtcpfdoador
            // 
            this.rbtcpfdoador.AutoSize = true;
            this.rbtcpfdoador.Location = new System.Drawing.Point(-2, 51);
            this.rbtcpfdoador.Margin = new System.Windows.Forms.Padding(4);
            this.rbtcpfdoador.Name = "rbtcpfdoador";
            this.rbtcpfdoador.Size = new System.Drawing.Size(197, 23);
            this.rbtcpfdoador.TabIndex = 2;
            this.rbtcpfdoador.TabStop = true;
            this.rbtcpfdoador.Text = "Buscar por cpfdoador: ";
            this.rbtcpfdoador.UseVisualStyleBackColor = true;
            this.rbtcpfdoador.CheckedChanged += new System.EventHandler(this.rbtcpfdoador_CheckedChanged);
            // 
            // rbtnomepet
            // 
            this.rbtnomepet.AutoSize = true;
            this.rbtnomepet.Location = new System.Drawing.Point(13, 88);
            this.rbtnomepet.Margin = new System.Windows.Forms.Padding(4);
            this.rbtnomepet.Name = "rbtnomepet";
            this.rbtnomepet.Size = new System.Drawing.Size(171, 23);
            this.rbtnomepet.TabIndex = 3;
            this.rbtnomepet.TabStop = true;
            this.rbtnomepet.Text = "Buscar por modelo:";
            this.rbtnomepet.UseVisualStyleBackColor = true;
            // 
            // btnpesquisarroupa
            // 
            this.btnpesquisarroupa.BackColor = System.Drawing.Color.Aqua;
            this.btnpesquisarroupa.Location = new System.Drawing.Point(345, 46);
            this.btnpesquisarroupa.Margin = new System.Windows.Forms.Padding(4);
            this.btnpesquisarroupa.Name = "btnpesquisarroupa";
            this.btnpesquisarroupa.Size = new System.Drawing.Size(131, 68);
            this.btnpesquisarroupa.TabIndex = 4;
            this.btnpesquisarroupa.Text = "BUSCAR";
            this.btnpesquisarroupa.UseVisualStyleBackColor = false;
            this.btnpesquisarroupa.Click += new System.EventHandler(this.btnbuscarpet_Click);
            // 
            // txtmodelodados
            // 
            this.txtmodelodados.Location = new System.Drawing.Point(197, 215);
            this.txtmodelodados.Margin = new System.Windows.Forms.Padding(4);
            this.txtmodelodados.Name = "txtmodelodados";
            this.txtmodelodados.Size = new System.Drawing.Size(141, 26);
            this.txtmodelodados.TabIndex = 6;
            // 
            // txtcpfdoadordados
            // 
            this.txtcpfdoadordados.Location = new System.Drawing.Point(196, 253);
            this.txtcpfdoadordados.Margin = new System.Windows.Forms.Padding(4);
            this.txtcpfdoadordados.Name = "txtcpfdoadordados";
            this.txtcpfdoadordados.Size = new System.Drawing.Size(141, 26);
            this.txtcpfdoadordados.TabIndex = 7;
            this.txtcpfdoadordados.TextChanged += new System.EventHandler(this.textBox5_TextChanged);
            // 
            // txtcordados
            // 
            this.txtcordados.Location = new System.Drawing.Point(196, 294);
            this.txtcordados.Margin = new System.Windows.Forms.Padding(4);
            this.txtcordados.Name = "txtcordados";
            this.txtcordados.Size = new System.Drawing.Size(141, 26);
            this.txtcordados.TabIndex = 8;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(142, 297);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(40, 19);
            this.label1.TabIndex = 9;
            this.label1.Text = "COR";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(57, 256);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(131, 19);
            this.label2.TabIndex = 10;
            this.label2.Text = "CPF DO DOADOR";
            // 
            // btnalterarroupa
            // 
            this.btnalterarroupa.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnalterarroupa.Location = new System.Drawing.Point(345, 171);
            this.btnalterarroupa.Margin = new System.Windows.Forms.Padding(4);
            this.btnalterarroupa.Name = "btnalterarroupa";
            this.btnalterarroupa.Size = new System.Drawing.Size(131, 74);
            this.btnalterarroupa.TabIndex = 13;
            this.btnalterarroupa.Text = "ALTERAR";
            this.btnalterarroupa.UseVisualStyleBackColor = false;
            this.btnalterarroupa.Click += new System.EventHandler(this.btnalterarpet_Click);
            // 
            // btnexcluirroupa
            // 
            this.btnexcluirroupa.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnexcluirroupa.Location = new System.Drawing.Point(345, 253);
            this.btnexcluirroupa.Margin = new System.Windows.Forms.Padding(4);
            this.btnexcluirroupa.Name = "btnexcluirroupa";
            this.btnexcluirroupa.Size = new System.Drawing.Size(131, 71);
            this.btnexcluirroupa.TabIndex = 14;
            this.btnexcluirroupa.Text = "EXCLUIR";
            this.btnexcluirroupa.UseVisualStyleBackColor = false;
            // 
            // cbxmodelo
            // 
            this.cbxmodelo.FormattingEnabled = true;
            this.cbxmodelo.Location = new System.Drawing.Point(196, 87);
            this.cbxmodelo.Margin = new System.Windows.Forms.Padding(4);
            this.cbxmodelo.Name = "cbxmodelo";
            this.cbxmodelo.Size = new System.Drawing.Size(141, 27);
            this.cbxmodelo.TabIndex = 15;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(110, 177);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(85, 19);
            this.label3.TabIndex = 16;
            this.label3.Text = "TAMANHO";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(108, 218);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(74, 19);
            this.label4.TabIndex = 17;
            this.label4.Text = "MODELO";
            // 
            // txttamanhodados
            // 
            this.txttamanhodados.Location = new System.Drawing.Point(197, 174);
            this.txttamanhodados.Name = "txttamanhodados";
            this.txttamanhodados.Size = new System.Drawing.Size(141, 26);
            this.txttamanhodados.TabIndex = 18;
            // 
            // Dadosroupa
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(489, 369);
            this.Controls.Add(this.txttamanhodados);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.cbxmodelo);
            this.Controls.Add(this.btnexcluirroupa);
            this.Controls.Add(this.btnalterarroupa);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtcordados);
            this.Controls.Add(this.txtcpfdoadordados);
            this.Controls.Add(this.txtmodelodados);
            this.Controls.Add(this.btnpesquisarroupa);
            this.Controls.Add(this.rbtnomepet);
            this.Controls.Add(this.rbtcpfdoador);
            this.Controls.Add(this.txtcpfdoador);
            this.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Dadosroupa";
            this.Text = "Dados Pet";
            this.Load += new System.EventHandler(this.Dadosroupa_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        private void btnalterarpet_Click(object sender, EventArgs e)
        {
            throw new NotImplementedException();
        }

        private void btnbuscarpet_Click(object sender, EventArgs e)
        {
            throw new NotImplementedException();
        }

        #endregion

        private System.Windows.Forms.TextBox txtcpfdoador;
        private System.Windows.Forms.RadioButton rbtcpfdoador;
        private System.Windows.Forms.RadioButton rbtnomepet;
        private System.Windows.Forms.Button btnpesquisarroupa;
        private System.Windows.Forms.TextBox txtmodelodados;
        private System.Windows.Forms.TextBox txtcpfdoadordados;
        private System.Windows.Forms.TextBox txtcordados;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnalterarroupa;
        private System.Windows.Forms.Button btnexcluirroupa;
        private System.Windows.Forms.ComboBox cbxmodelo;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txttamanhodados;
    }
}