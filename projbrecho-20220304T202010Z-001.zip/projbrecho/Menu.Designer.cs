﻿namespace Projetobrecho
{
    partial class Menu
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.cadastrarClienteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.alterarExcluirDadosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cadastrarCLienteToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.adotarPetToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.alterarExcluirDadosToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.adotarPetToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.consultarPetsDisponiveisParaAdoçãoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem1});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(12, 4, 0, 4);
            this.menuStrip1.Size = new System.Drawing.Size(435, 29);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.toolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.cadastrarClienteToolStripMenuItem,
            this.adotarPetToolStripMenuItem,
            this.consultarPetsDisponiveisParaAdoçãoToolStripMenuItem});
            this.toolStripMenuItem1.Font = new System.Drawing.Font("Cambria", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(62, 21);
            this.toolStripMenuItem1.Text = "MENU";
            // 
            // cadastrarClienteToolStripMenuItem
            // 
            this.cadastrarClienteToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.cadastrarClienteToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.alterarExcluirDadosToolStripMenuItem,
            this.cadastrarCLienteToolStripMenuItem1});
            this.cadastrarClienteToolStripMenuItem.Name = "cadastrarClienteToolStripMenuItem";
            this.cadastrarClienteToolStripMenuItem.Size = new System.Drawing.Size(351, 22);
            this.cadastrarClienteToolStripMenuItem.Text = "Opções do Cliente";
            this.cadastrarClienteToolStripMenuItem.Click += new System.EventHandler(this.cadastrarClienteToolStripMenuItem_Click);
            // 
            // alterarExcluirDadosToolStripMenuItem
            // 
            this.alterarExcluirDadosToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.alterarExcluirDadosToolStripMenuItem.Name = "alterarExcluirDadosToolStripMenuItem";
            this.alterarExcluirDadosToolStripMenuItem.Size = new System.Drawing.Size(232, 22);
            this.alterarExcluirDadosToolStripMenuItem.Text = "Alterar/Excluir dados";
            this.alterarExcluirDadosToolStripMenuItem.Click += new System.EventHandler(this.alterarExcluirDadosToolStripMenuItem_Click);
            // 
            // cadastrarCLienteToolStripMenuItem1
            // 
            this.cadastrarCLienteToolStripMenuItem1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.cadastrarCLienteToolStripMenuItem1.Name = "cadastrarCLienteToolStripMenuItem1";
            this.cadastrarCLienteToolStripMenuItem1.Size = new System.Drawing.Size(232, 22);
            this.cadastrarCLienteToolStripMenuItem1.Text = "Cadastrar CLiente";
            this.cadastrarCLienteToolStripMenuItem1.Click += new System.EventHandler(this.cadastrarCLienteToolStripMenuItem1_Click);
            // 
            // adotarPetToolStripMenuItem
            // 
            this.adotarPetToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.adotarPetToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.alterarExcluirDadosToolStripMenuItem1,
            this.adotarPetToolStripMenuItem1});
            this.adotarPetToolStripMenuItem.Name = "adotarPetToolStripMenuItem";
            this.adotarPetToolStripMenuItem.Size = new System.Drawing.Size(351, 22);
            this.adotarPetToolStripMenuItem.Text = "Adotar Pet";
            this.adotarPetToolStripMenuItem.Click += new System.EventHandler(this.adotarPetToolStripMenuItem_Click);
            // 
            // alterarExcluirDadosToolStripMenuItem1
            // 
            this.alterarExcluirDadosToolStripMenuItem1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.alterarExcluirDadosToolStripMenuItem1.Name = "alterarExcluirDadosToolStripMenuItem1";
            this.alterarExcluirDadosToolStripMenuItem1.Size = new System.Drawing.Size(235, 22);
            this.alterarExcluirDadosToolStripMenuItem1.Text = "Alterar/Excluir dados ";
            this.alterarExcluirDadosToolStripMenuItem1.Click += new System.EventHandler(this.alterarExcluirDadosToolStripMenuItem1_Click);
            // 
            // adotarPetToolStripMenuItem1
            // 
            this.adotarPetToolStripMenuItem1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.adotarPetToolStripMenuItem1.Name = "adotarPetToolStripMenuItem1";
            this.adotarPetToolStripMenuItem1.Size = new System.Drawing.Size(235, 22);
            this.adotarPetToolStripMenuItem1.Text = "Adotar Pet";
            this.adotarPetToolStripMenuItem1.Click += new System.EventHandler(this.adotarPetToolStripMenuItem1_Click);
            // 
            // consultarPetsDisponiveisParaAdoçãoToolStripMenuItem
            // 
            this.consultarPetsDisponiveisParaAdoçãoToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.consultarPetsDisponiveisParaAdoçãoToolStripMenuItem.Name = "consultarPetsDisponiveisParaAdoçãoToolStripMenuItem";
            this.consultarPetsDisponiveisParaAdoçãoToolStripMenuItem.Size = new System.Drawing.Size(351, 22);
            this.consultarPetsDisponiveisParaAdoçãoToolStripMenuItem.Text = "Consultar Pets disponiveis para adoção";
            this.consultarPetsDisponiveisParaAdoçãoToolStripMenuItem.Click += new System.EventHandler(this.consultarPetsDisponiveisParaAdoçãoToolStripMenuItem_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(86, 70);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(291, 25);
            this.label2.TabIndex = 2;
            this.label2.Text = "BEM VINDO AO PETSHOP";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(33, 95);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(396, 25);
            this.label1.TabIndex = 3;
            this.label1.Text = "TCHURUSBANGO TCHURUSBAGOS";
            // 
            // Menu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(13F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(435, 323);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.menuStrip1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(6);
            this.Name = "Menu";
            this.Text = "PetShop";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem cadastrarClienteToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem alterarExcluirDadosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem adotarPetToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem alterarExcluirDadosToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem consultarPetsDisponiveisParaAdoçãoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cadastrarCLienteToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem adotarPetToolStripMenuItem1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
    }
}

