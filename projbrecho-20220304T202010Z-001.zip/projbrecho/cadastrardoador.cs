﻿using System;
using System.Windows.Forms;

namespace Projetobrecho
{
    public partial class Cadastrardoador : Form
    {
        public Cadastrardoador()
        {
            InitializeComponent();
        }

        private void Cadastrardoador_FormClosed(object sender, FormClosedEventArgs e)
        {
            if (Application.OpenForms.Count == 0)
            {
                Application.Exit();
            }
            else
            {
                foreach (Form formABERTO in Application.OpenForms)
                {
                    if (formABERTO is Menu)
                    {
                        formABERTO.Show();
                        break;
                    }
                }
            }
        }

        private void btnCadastrardoador_Click(object sender, EventArgs e)
        {
            string nome = txtnome.Text;
            string cpf = txtcpf.Text;
            string enredeco = txtendereco.Text;
            string telefone = txtcel.Text;

            doador c = new doador(nome, cpf, enredeco, telefone);
            Bancodedados BD = new Bancodedados();

            if (BD.Conectar())
            {
                if (BD.Cadastrardoador(c))
                {
                    MessageBox.Show("doador cadastrado! Bem vindo!");
                    BD.Desconectar();

                }
                else
                    MessageBox.Show("Não foi possível cadastrar");

                txtnome.Text = "";
                txtcpf.Text = "";
                txtendereco.Text = "";
                txtcel.Text = "";
            }
        }

        private void Cadastrardoador_Load(object sender, EventArgs e)
        {

        }
    }
}
