﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace Projetobrecho
{
    public partial class Dadosdoador : Form
    {
        public Dadosdoador()
        {
            InitializeComponent();
        }
        List<doador> doador;
        doador escolhido;

        private void cbxnome_SelectedIndexChanged(object sender, EventArgs e)
        {
            int posicao = cbxnome.SelectedIndex;
            escolhido = doador[posicao];
            txtdadosnome.Text = escolhido.nome;
            txtdadosendereco.Text = escolhido.endereco;
            txtdadoscpf.Text = escolhido.cpf;
            txtdadostel.Text = escolhido.telefone;
        }



        private void btnpesquisar_Click(object sender, EventArgs e)
        {
            Bancodedados bd = new Bancodedados();
            if (bd.Conectar())
            {

                if (rbtcpf.Checked)
                {
                    string cpf = txtdadoscpf.Text;
                    escolhido = bd.pesquisadoadorporcpf(cpf);
                    bd.Desconectar();

                    if (escolhido == null)
                        MessageBox.Show("Não foi possível encontrar o doador", "tente novamente!");
                    else
                    {
                        txtdadosnome.Text = escolhido.nome;
                        txtdadoscpf.Text = escolhido.cpf;
                        txtdadosendereco.Text = escolhido.endereco;
                        txtdadostel.Text = escolhido.telefone;
                    }

                }
                else
                {
                    string parteN = cbxnome.Text;
                    cbxnome.Items.Clear();
                    doador = bd.pesquisadoadorpornome(parteN);
                    for (int i = 0; i < doador.Count; i++)
                        cbxnome.Items.Add(doador[i].nome);


                }
            }
        }



        private void rbtnome_CheckedChanged(object sender, EventArgs e)
        {
            txtcpf.Text = "";
            txtcpf.Enabled = false;
            cbxnome.Enabled = true;

        }

        private void rbtcpf_CheckedChanged_1(object sender, EventArgs e)
        {
            cbxnome.Text = "";
            cbxnome.Enabled = false;
            txtcpf.Enabled = true;
        }

        private void txtdadosnome_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnexcluir_Click(object sender, EventArgs e)
        {
            Bancodedados BD = new Bancodedados();
            escolhido.cpf = txtdadoscpf.Text;

            if (BD.Conectar())
            {

                if (BD.Excluirdoador(escolhido))
                {
                    MessageBox.Show("Até a Próxima!");

                    txtdadosnome.Text = "";
                    txtdadoscpf.Text = "";
                    txtdadosendereco.Text = "";
                    txtdadostel.Text = "";
                    txtcpf.Text = " ";
                    cbxnome.Text = " ";
                }
                else
                    MessageBox.Show("Não foi possível excluir o doador");
            }
            else
                MessageBox.Show("Erro de conexão");
        }

        private void Dadosdoador_FormClosed(object sender, FormClosedEventArgs e)
        {
            if (Application.OpenForms.Count == 0)
            {
                Application.Exit();
            }
            else
            {
                foreach (Form formABERTO in Application.OpenForms)
                {
                    if (formABERTO is Menu)
                    {
                        formABERTO.Show();
                        break;
                    }
                }
            }
        }

        private void btnalterar_Click(object sender, EventArgs e)
        {
            {
                Bancodedados bd = new Bancodedados();

                escolhido.nome = txtdadosnome.Text;

                escolhido.cpf = txtdadoscpf.Text;

                escolhido.endereco = txtdadosendereco.Text;

                escolhido.telefone = txtdadostel.Text;



                if (bd.Conectar())
                {


                    if (bd.alteradoador(escolhido))
                    {
                        MessageBox.Show("Os dados do doador foram alterados");

                    }
                    else
                        MessageBox.Show("Não foi possível alterar os dados do doador");

                }
                else
                    MessageBox.Show("Erro de conexão", "Alerta!");

            }



        }
    }
}