﻿using System;
using System.Windows.Forms;

namespace Projetobrecho
{
    public partial class receberroupa : Form
    {
        public receberroupa()
        {
            InitializeComponent();
        }


        private void receberroupa_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (Application.OpenForms.Count == 0)
            {
                Application.Exit();
            }
            else
            {
                foreach (Form formABERTO in Application.OpenForms)
                {
                    if (formABERTO is Menu)
                    {
                        formABERTO.Show();
                        break;
                    }
                }
            }
        }

        private void btnreceber_Click(object sender, EventArgs e)
        {
            string modelo = cboxmodelo.Text;
            string cor = txtcor.Text;
            string cpfdoador = txtcpfdoador.Text;
            string tamanho = txttamanho.Text;



            roupa P = new roupa(modelo, cor, tamanho, cpfdoador);
            Bancodedados BD = new Bancodedados();

            if (BD.Conectar())
            {
                if ((bool)BD.receberroupar)
                {
                    MessageBox.Show("roupa requerida Parabéns!!!");
                    BD.Desconectar();

                }
                else
                    MessageBox.Show("Não foi possível requerer");

                txtcor.Text = "";
                txtcpfdoador.Text = "";
                txttamanho.Text = "";
                cboxmodelo.Text = "";
            }
        }
    }
}
