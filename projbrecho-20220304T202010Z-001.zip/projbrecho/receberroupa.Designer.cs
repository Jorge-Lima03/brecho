﻿namespace Projetobrecho
{
	partial class receberroupa
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(receberroupa));
            this.btnadotar = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txtcor = new System.Windows.Forms.TextBox();
            this.txttamanho = new System.Windows.Forms.TextBox();
            this.txtcpfdoador = new System.Windows.Forms.TextBox();
            this.cboxmodelo = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // btnadotar
            // 
            this.btnadotar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.btnadotar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnadotar.Font = new System.Drawing.Font("Cambria", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnadotar.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.btnadotar.Location = new System.Drawing.Point(374, 43);
            this.btnadotar.Name = "btnadotar";
            this.btnadotar.Size = new System.Drawing.Size(155, 145);
            this.btnadotar.TabIndex = 0;
            this.btnadotar.Text = "ADOTAR";
            this.btnadotar.UseVisualStyleBackColor = false;
            this.btnadotar.UseWaitCursor = true;
            this.btnadotar.Click += new System.EventHandler(this.btnreceber_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(18, 49);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(193, 22);
            this.label1.TabIndex = 1;
            this.label1.Text = "ESCOLHA O MODELO:";
            this.label1.UseWaitCursor = true;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(66, 106);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(145, 22);
            this.label2.TabIndex = 2;
            this.label2.Text = "COR DA ROUPA:";
            this.label2.UseWaitCursor = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(60, 167);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(143, 22);
            this.label3.TabIndex = 3;
            this.label3.Text = "SEU TAMANHO:";
            this.label3.UseWaitCursor = true;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(46, 225);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(158, 22);
            this.label4.TabIndex = 4;
            this.label4.Text = "CPF DO DOADOR:";
            this.label4.UseWaitCursor = true;
            // 
            // txtcor
            // 
            this.txtcor.Location = new System.Drawing.Point(210, 103);
            this.txtcor.Name = "txtcor";
            this.txtcor.Size = new System.Drawing.Size(143, 30);
            this.txtcor.TabIndex = 6;
            this.txtcor.UseWaitCursor = true;
            // 
            // txttamanho
            // 
            this.txttamanho.Location = new System.Drawing.Point(210, 164);
            this.txttamanho.Name = "txttamanho";
            this.txttamanho.Size = new System.Drawing.Size(143, 30);
            this.txttamanho.TabIndex = 7;
            this.txttamanho.UseWaitCursor = true;
            // 
            // txtcpfdoador
            // 
            this.txtcpfdoador.Location = new System.Drawing.Point(210, 222);
            this.txtcpfdoador.Name = "txtcpfdoador";
            this.txtcpfdoador.Size = new System.Drawing.Size(143, 30);
            this.txtcpfdoador.TabIndex = 8;
            this.txtcpfdoador.UseWaitCursor = true;
            // 
            // cboxmodelo
            // 
            this.cboxmodelo.FormattingEnabled = true;
            this.cboxmodelo.Items.AddRange(new object[] {
            "CACHORRO",
            "GATO"});
            this.cboxmodelo.Location = new System.Drawing.Point(210, 46);
            this.cboxmodelo.Name = "cboxmodelo";
            this.cboxmodelo.Size = new System.Drawing.Size(143, 30);
            this.cboxmodelo.TabIndex = 9;
            this.cboxmodelo.UseWaitCursor = true;
            // 
            // receberroupa
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 22F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.ClientSize = new System.Drawing.Size(541, 303);
            this.Controls.Add(this.cboxmodelo);
            this.Controls.Add(this.txtcpfdoador);
            this.Controls.Add(this.txttamanho);
            this.Controls.Add(this.txtcor);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnadotar);
            this.Font = new System.Drawing.Font("Cambria", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(6, 5, 6, 5);
            this.Name = "receberroupa";
            this.Text = "AdotarPet";
            this.TransparencyKey = System.Drawing.Color.Black;
            this.UseWaitCursor = true;
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.receberroupa_FormClosing);
            this.ResumeLayout(false);
            this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Button btnadotar;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.TextBox txtcor;
		private System.Windows.Forms.TextBox txttamanho;
		private System.Windows.Forms.TextBox txtcpfdoador;
		private System.Windows.Forms.ComboBox cboxmodelo;
	}
}