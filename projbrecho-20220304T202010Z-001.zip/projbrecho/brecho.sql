-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 06-Jan-2021 às 22:09
-- Versão do servidor: 5.7.17
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `brecho`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `doador`
--

CREATE TABLE `doador` (
  `cpf` bigint(11) NOT NULL,
  `nome` char(100) NOT NULL,
  `endereço` char(200) NOT NULL,
  `telefone` bigint(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `doador`
--

INSERT INTO `doador` (`cpf`, `nome`, `endereço`, `telefone`) VALUES
(16440861743, 'gabriel paulo da silva', 'av engenheiro jose de castro 17', 21979435095),
(26738940816, 'eustacio rodrigues', 'rua tranquila 231', 21673546783),
(17446521906, 'diego da convençao', 'rua do odio 23', 21738746539),
(19126736521, 'jade campelo', 'rua barao de melgaço 1083', 21878364750);

-- --------------------------------------------------------

--
-- Estrutura da tabela `roupas`
--

CREATE TABLE `roupas` (
  `CPF doador` bigint(11) NOT NULL,
  `modelo` varchar(100) NOT NULL,
  `cor` varchar(50) NOT NULL,
  `tamanho` int(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `roupas`
--

INSERT INTO `roupas` (`CPF doador`, `modelo`, `cor`, `tamanho`) VALUES
(16440861743, 'vestido', 'azul', 40),
(17848938716, 'camisa masculina', 'vermelho', 35),
(15647839029, 'calça masculina', 'azul escuro', 42),
(15436728409, 'camiseta feminina', 'preta', 49);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `doador`
--
ALTER TABLE `doador`
  ADD PRIMARY KEY (`cpf`);

--
-- Indexes for table `roupas`
--
ALTER TABLE `roupas`
  ADD PRIMARY KEY (`CPF doador`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `doador`
--
ALTER TABLE `doador`
  MODIFY `cpf` bigint(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2147483647;
--
-- AUTO_INCREMENT for table `roupas`
--
ALTER TABLE `roupas`
  MODIFY `CPF doador` bigint(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2147483647;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
