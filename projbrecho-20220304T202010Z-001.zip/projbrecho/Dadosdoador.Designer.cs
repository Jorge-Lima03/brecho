﻿namespace Projetobrecho
{
    partial class Dadosdoador
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnbuscar = new System.Windows.Forms.Button();
            this.btnalterar = new System.Windows.Forms.Button();
            this.btnexcluir = new System.Windows.Forms.Button();
            this.rbtcpf = new System.Windows.Forms.RadioButton();
            this.rbtnome = new System.Windows.Forms.RadioButton();
            this.cbxnome = new System.Windows.Forms.ComboBox();
            this.txtcpf = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txtdadosnome = new System.Windows.Forms.TextBox();
            this.txtdadosendereco = new System.Windows.Forms.TextBox();
            this.txtdadostel = new System.Windows.Forms.TextBox();
            this.txtdadoscpf = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // btnbuscar
            // 
            this.btnbuscar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.btnbuscar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnbuscar.ForeColor = System.Drawing.Color.Black;
            this.btnbuscar.Location = new System.Drawing.Point(328, 54);
            this.btnbuscar.Name = "btnbuscar";
            this.btnbuscar.Size = new System.Drawing.Size(119, 63);
            this.btnbuscar.TabIndex = 0;
            this.btnbuscar.Text = "BUSCAR";
            this.btnbuscar.UseVisualStyleBackColor = false;
            this.btnbuscar.UseWaitCursor = true;
            this.btnbuscar.Click += new System.EventHandler(this.btnpesquisar_Click);
            // 
            // btnalterar
            // 
            this.btnalterar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.btnalterar.Location = new System.Drawing.Point(328, 182);
            this.btnalterar.Name = "btnalterar";
            this.btnalterar.Size = new System.Drawing.Size(119, 47);
            this.btnalterar.TabIndex = 1;
            this.btnalterar.Text = "ALTERAR";
            this.btnalterar.UseVisualStyleBackColor = false;
            this.btnalterar.UseWaitCursor = true;
            this.btnalterar.Click += new System.EventHandler(this.btnalterar_Click);
            // 
            // btnexcluir
            // 
            this.btnexcluir.BackColor = System.Drawing.Color.Aqua;
            this.btnexcluir.Location = new System.Drawing.Point(328, 250);
            this.btnexcluir.Name = "btnexcluir";
            this.btnexcluir.Size = new System.Drawing.Size(119, 47);
            this.btnexcluir.TabIndex = 2;
            this.btnexcluir.Text = "EXCLUIR";
            this.btnexcluir.UseVisualStyleBackColor = false;
            this.btnexcluir.UseWaitCursor = true;
            this.btnexcluir.Click += new System.EventHandler(this.btnexcluir_Click);
            // 
            // rbtcpf
            // 
            this.rbtcpf.AutoSize = true;
            this.rbtcpf.Location = new System.Drawing.Point(32, 57);
            this.rbtcpf.Name = "rbtcpf";
            this.rbtcpf.Size = new System.Drawing.Size(140, 23);
            this.rbtcpf.TabIndex = 3;
            this.rbtcpf.TabStop = true;
            this.rbtcpf.Text = "Buscar por CPF";
            this.rbtcpf.UseVisualStyleBackColor = true;
            this.rbtcpf.UseWaitCursor = true;
            this.rbtcpf.CheckedChanged += new System.EventHandler(this.rbtcpf_CheckedChanged_1);
            // 
            // rbtnome
            // 
            this.rbtnome.AutoSize = true;
            this.rbtnome.Location = new System.Drawing.Point(32, 90);
            this.rbtnome.Name = "rbtnome";
            this.rbtnome.Size = new System.Drawing.Size(154, 23);
            this.rbtnome.TabIndex = 4;
            this.rbtnome.TabStop = true;
            this.rbtnome.Text = "Buscar por Nome";
            this.rbtnome.UseVisualStyleBackColor = true;
            this.rbtnome.UseWaitCursor = true;
            this.rbtnome.CheckedChanged += new System.EventHandler(this.rbtnome_CheckedChanged);
            // 
            // cbxnome
            // 
            this.cbxnome.FormattingEnabled = true;
            this.cbxnome.Location = new System.Drawing.Point(192, 90);
            this.cbxnome.Name = "cbxnome";
            this.cbxnome.Size = new System.Drawing.Size(121, 27);
            this.cbxnome.TabIndex = 5;
            this.cbxnome.UseWaitCursor = true;
            this.cbxnome.SelectedIndexChanged += new System.EventHandler(this.cbxnome_SelectedIndexChanged);
            // 
            // txtcpf
            // 
            this.txtcpf.Location = new System.Drawing.Point(192, 54);
            this.txtcpf.Name = "txtcpf";
            this.txtcpf.Size = new System.Drawing.Size(121, 26);
            this.txtcpf.TabIndex = 6;
            this.txtcpf.UseWaitCursor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(72, 167);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(54, 19);
            this.label1.TabIndex = 7;
            this.label1.Text = "NOME";
            this.label1.UseWaitCursor = true;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(49, 210);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(77, 19);
            this.label2.TabIndex = 8;
            this.label2.Text = "endereco";
            this.label2.UseWaitCursor = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(47, 250);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(68, 19);
            this.label3.TabIndex = 9;
            this.label3.Text = "telefone";
            this.label3.UseWaitCursor = true;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(87, 288);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(37, 19);
            this.label4.TabIndex = 10;
            this.label4.Text = "CPF";
            this.label4.UseWaitCursor = true;
            // 
            // txtdadosnome
            // 
            this.txtdadosnome.Location = new System.Drawing.Point(132, 164);
            this.txtdadosnome.Name = "txtdadosnome";
            this.txtdadosnome.Size = new System.Drawing.Size(181, 26);
            this.txtdadosnome.TabIndex = 11;
            this.txtdadosnome.UseWaitCursor = true;
            this.txtdadosnome.TextChanged += new System.EventHandler(this.txtdadosnome_TextChanged);
            // 
            // txtdadosendereco
            // 
            this.txtdadosendereco.Location = new System.Drawing.Point(132, 203);
            this.txtdadosendereco.Name = "txtdadosendereco";
            this.txtdadosendereco.Size = new System.Drawing.Size(181, 26);
            this.txtdadosendereco.TabIndex = 12;
            this.txtdadosendereco.UseWaitCursor = true;
            // 
            // txtdadostel
            // 
            this.txtdadostel.Location = new System.Drawing.Point(132, 247);
            this.txtdadostel.Name = "txtdadostel";
            this.txtdadostel.Size = new System.Drawing.Size(181, 26);
            this.txtdadostel.TabIndex = 13;
            this.txtdadostel.UseWaitCursor = true;
            // 
            // txtdadoscpf
            // 
            this.txtdadoscpf.Location = new System.Drawing.Point(132, 288);
            this.txtdadoscpf.Name = "txtdadoscpf";
            this.txtdadoscpf.Size = new System.Drawing.Size(181, 26);
            this.txtdadoscpf.TabIndex = 14;
            this.txtdadoscpf.UseWaitCursor = true;
            // 
            // Dadosdoador
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.ClientSize = new System.Drawing.Size(476, 360);
            this.Controls.Add(this.txtdadoscpf);
            this.Controls.Add(this.txtdadostel);
            this.Controls.Add(this.txtdadosendereco);
            this.Controls.Add(this.txtdadosnome);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtcpf);
            this.Controls.Add(this.cbxnome);
            this.Controls.Add(this.rbtnome);
            this.Controls.Add(this.rbtcpf);
            this.Controls.Add(this.btnexcluir);
            this.Controls.Add(this.btnalterar);
            this.Controls.Add(this.btnbuscar);
            this.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Dadosdoador";
            this.Text = "Dadosdoador";
            this.TopMost = true;
            this.UseWaitCursor = true;
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Dadosdoador_FormClosed);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnbuscar;
        private System.Windows.Forms.Button btnalterar;
        private System.Windows.Forms.Button btnexcluir;
        private System.Windows.Forms.RadioButton rbtcpf;
        private System.Windows.Forms.RadioButton rbtnome;
        private System.Windows.Forms.ComboBox cbxnome;
        private System.Windows.Forms.TextBox txtcpf;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtdadosnome;
        private System.Windows.Forms.TextBox txtdadosendereco;
        private System.Windows.Forms.TextBox txtdadostel;
        private System.Windows.Forms.TextBox txtdadoscpf;
    }
}