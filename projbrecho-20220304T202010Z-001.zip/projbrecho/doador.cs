﻿namespace Projetobrecho
{
    class doador
    {
        public string nome { get; set; }
        public string cpf { get; set; }
        public string endereco { get; set; }
        public string telefone { get; set; }

        public doador(string nome, string cpf, string endereco, string telefone)
        {
            this.nome = nome;
            this.cpf = cpf;
            this.endereco = endereco;
            this.telefone = telefone;
        }
    }
}
