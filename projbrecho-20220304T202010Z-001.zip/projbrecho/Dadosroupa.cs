﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace Projetobrecho
{
    public partial class Dadosroupa : Form
    {
        public Dadosroupa()
        {
            InitializeComponent();
        }

        List<roupa> roupa1;
        roupa escolhidoroupa;


        private void cbxmodelo_SelectedIndexChanged(object sender, EventArgs e)
        {
            int posicao = cbxmodelo.SelectedIndex;
            escolhidoroupa = roupa1[posicao];
            txtmodelodados.Text = escolhidoroupa.modelo;
            txtcpfdoadordados.Text = escolhidoroupa.cpfdoador;
            txttamanhodados.Text = escolhidoroupa.tamanho;
            txtcordados.Text = escolhidoroupa.cor;
        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnpesquisarroupa_Click(object sender, EventArgs e)
        {
            Bancodedados bd = new Bancodedados();
            if (bd.Conectar())
            {

                if (rbtcpfdoador.Checked)
                {
                    string cpfdoador = txtcpfdoador.Text;
                    escolhidoroupa = bd.pesquisaroupaporcpfdoador(cpfdoador);
                    bd.Desconectar();

                    if (escolhidoroupa == null)
                        MessageBox.Show("Não foi possível pesquisar a roupa", "tente novamente!");
                    else
                    {
                        txtmodelodados.Text = escolhidoroupa.modelo;
                        txtcpfdoadordados.Text = escolhidoroupa.cpfdoador;
                        txttamanhodados.Text = escolhidoroupa.tamanho;
                        txtcordados.Text = escolhidoroupa.cor;
                    }

                }
                else
                {

                    string parteN = cbxmodelo.Text;
                    cbxmodelo.Items.Clear();
                    roupa1 = bd.pesquisarroupapormodelo(parteN);
                    for (int i = 0; i < roupa1.Count; i++)
                        cbxmodelo.Items.Add(roupa1[i].tamanho);


                }
            }
        }

        private void btnalterarroupa_Click(object sender, EventArgs e)
        {




        }

        private void rbtcpfdoador_CheckedChanged(object sender, EventArgs e)
        {
            cbxmodelo.Text = "";
            cbxmodelo.Enabled = false;
            txtcpfdoador.Enabled = true;
        }





        private void rbtmodelo_CheckedChanged(object sender, EventArgs e)
        {

            txtcpfdoador.Text = "";
            txtcpfdoador.Enabled = false;
            cbxmodelo.Enabled = true;

        }

        private void Dadosroupa_Load(object sender, EventArgs e)
        {

        }
    }



}
