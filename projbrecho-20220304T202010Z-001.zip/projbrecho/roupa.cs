﻿namespace Projetobrecho
{
    class roupa
    {
        public string modelo { get; set; }
        public string cor { get; set; }
        public string cpfdoador { get; set; }
        public string tamanho { get; set; }


        public roupa(string modelo, string cor, string tamanho, string cpfdoador)
        {
            this.modelo = modelo;
            this.cor = cor;
            this.tamanho = tamanho;
            this.cpfdoador = cpfdoador;

        }
    }
}
