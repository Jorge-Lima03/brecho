﻿using System;
using System.Windows.Forms;

namespace Projetobrecho
{
    public partial class Menu : Form
    {
        public Menu()
        {

        }

        private void cadastrarClienteToolStripMenuItem_Click(object sender, EventArgs e)
        {


        }

        private void adotarPetToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void alterarExcluirDadosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Dadosdoador D = new Dadosdoador();
            D.Show();
            this.Hide();
        }

        private void alterarExcluirDadosToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Dadosroupa DP = new Dadosroupa();
            DP.Show();
            this.Hide();
        }

        private void cadastrarCLienteToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Cadastrardoador C = new Cadastrardoador();
            C.Show();
            this.Hide();
        }

        private void adotarPetToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            receberroupa P = new receberroupa();
            P.Show();
            this.Hide();
        }

        private void consultarPetsDisponiveisParaAdoçãoToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }
    }
}
