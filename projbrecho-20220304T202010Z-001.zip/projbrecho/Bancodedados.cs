﻿using MySql.Data.MySqlClient;
using System.Collections.Generic;

namespace Projetobrecho
{
    class Bancodedados
    {
        MySqlConnection bdConn;
        internal object receberroupar;

        public bool Conectar()
        {
            bool sucesso = true;
            bdConn = new MySqlConnection("server=localhost;database=brechopj.bd;uid=root;pwd=''");
            try
            {
                bdConn.Open();

            }
            catch
            {
                sucesso = false;
            }

            return sucesso;
        }
        public void Desconectar()
        {
            bdConn.Close();
        }

        public bool Cadastrardoador(doador C)
        {
            bool retorno = true;

            try
            {
                MySqlCommand cmd = new MySqlCommand("INSERT INTO tab_cliente (nome, cpf, endereco, telefone) values (@nome, @cpf, @endereco, @telefone)", bdConn);
                cmd.Parameters.AddWithValue("@nome", C.nome);
                cmd.Parameters.AddWithValue("@cpf", C.cpf);
                cmd.Parameters.AddWithValue("@endereco", C.endereco);
                cmd.Parameters.AddWithValue("@telefone", C.telefone);
                cmd.ExecuteNonQuery();
            }
            catch
            {

                retorno = false;
            }

            return retorno;
        }

        public List<doador> pesquisadoadorpornome(string nome)
        {
            string nome2, cpf, endereco, telefone;
            string comando = "SELECT * FROM doador WHERE nome like @nome";
            MySqlCommand cmd = new MySqlCommand(comando, bdConn);
            cmd.Parameters.AddWithValue("@nome", nome + "%");
            MySqlDataReader reader = cmd.ExecuteReader();
            List<doador> clit = new List<doador>();
            while (reader.Read())
            {

                nome2 = reader["nome"].ToString();
                cpf = reader["cpf"].ToString();
                endereco = reader["endereco"].ToString();
                telefone = reader["telefone"].ToString();

                doador C = new doador(nome2, cpf, endereco, telefone);
                clit.Add(C);

            }
            reader.Close();
            return clit;

        }

        public doador pesquisadoadorporcpf(string cpf)
        {
            string nome, cpf2, endereco, telefone;
            string comando = "SELECT * FROM doador WHERE cpf like @cpf";
            MySqlCommand cmd = new MySqlCommand(comando, bdConn);
            cmd.Parameters.AddWithValue("@cpf", cpf + "%");
            MySqlDataReader reader = cmd.ExecuteReader();
            doador C = null;

            while (reader.Read())
            {

                cpf2 = reader["cpf"].ToString();
                nome = reader["nome"].ToString();
                endereco = reader["endereco"].ToString();
                telefone = reader["telefone"].ToString();

                C = new doador(nome, cpf2, endereco, telefone);

            }
            reader.Close();
            return C;

        }

        public bool alteradoador(doador C)
        {
            bool retorno = true;

            try
            {
                string comando = "UPDATE tab_cliente set nome = @nome , endereco = @endereco, telefone = @telefone where cpf = @cpf";
                MySqlCommand cmd = new MySqlCommand(comando, bdConn);
                cmd.Parameters.AddWithValue("@nome", C.nome);
                cmd.Parameters.AddWithValue("@cpf", C.cpf);
                cmd.Parameters.AddWithValue("@endereco", C.endereco);
                cmd.Parameters.AddWithValue("@telefone", C.telefone);
                cmd.ExecuteNonQuery();

            }
            catch
            {
                retorno = false;

            }

            return retorno;
        }



        public bool Excluirdoador(doador C)
        {
            bool retorno = true;

            try
            {

                string comando = "DELETE FROM doador where cpf = @cpf";
                MySqlCommand cmd = new MySqlCommand(comando, bdConn);
                cmd.Parameters.AddWithValue("@cpf", C.cpf);
                cmd.ExecuteNonQuery();

            }
            catch
            {

                retorno = false;
            }
            return retorno;
        }

        // PARTE DO PET

        public bool receberroupa(roupa P)
        {
            bool retorno = true;

            try
            {
                MySqlCommand cmd = new MySqlCommand("INSERT INTO roupas (modelo, cor, tamanho, cpfdoador) values (@modelo, @cor, @tamanho, @cpfdoador)", bdConn);
                cmd.Parameters.AddWithValue("@modelo", P.modelo);
                cmd.Parameters.AddWithValue("@cor", P.cor);
                cmd.Parameters.AddWithValue("@tamanho", P.tamanho);
                cmd.Parameters.AddWithValue("@cpfdoador", P.cpfdoador);
                cmd.ExecuteNonQuery();
            }
            catch
            {

                retorno = false;
            }

            return retorno;
        }


        public List<roupa> pesquisarroupapormodelo(string modelo1)
        {
            string modelo, cor, tamanho, cpfdoador;
            string comando = "SELECT * FROM roupas WHERE modelo like @modelo";
            MySqlCommand cmd = new MySqlCommand(comando, bdConn);
            cmd.Parameters.AddWithValue("@modelo", modelo1 + "%");
            MySqlDataReader reader = cmd.ExecuteReader();
            List<roupa> roupa1 = new List<roupa>();
            while (reader.Read())
            {

                modelo = reader["modelo"].ToString();
                cor = reader["cor"].ToString();
                tamanho = reader["tamanho"].ToString();
                cpfdoador = reader["cpfdoador"].ToString();

                roupa P = new roupa(modelo, cor, tamanho, cpfdoador);
                roupa1.Add(P);

            }
            reader.Close();
            return roupa1;
        }

        public roupa pesquisaroupaporcpfdoador(string cpfdoador)

        {
            string modelo, cor, tamanho, cpfdoador2;
            string comando = "SELECT * FROM roupas WHERE cpfdoador like @cpfdoador";
            MySqlCommand cmd = new MySqlCommand(comando, bdConn);
            cmd.Parameters.AddWithValue("@cpfdoador", cpfdoador + "%");
            MySqlDataReader reader = cmd.ExecuteReader();
            roupa P = null;

            while (reader.Read())
            {

                cpfdoador2 = reader["cpfdoador"].ToString();
                cor = reader["cor"].ToString();
                tamanho = reader["tamanho"].ToString();
                modelo = reader["modelo"].ToString();

                P = new roupa(modelo, cor, tamanho, cpfdoador2);

            }
            reader.Close();
            return P;

        }










    }

}
